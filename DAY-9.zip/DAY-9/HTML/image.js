function chaimg1(){
    document.getElementById("trns1").src="HAYA1.jpg"
}

function chaimg2(){
    document.getElementById("trns1").src="HAYA2.jpg"

}

function chaimg3(){
    document.getElementById("trns1").src="HAYA3.jpg"

}